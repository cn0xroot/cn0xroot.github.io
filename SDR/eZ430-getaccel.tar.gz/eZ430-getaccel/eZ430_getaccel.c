/*******************************************************************************
 *  eZ430_getaccel.c
 * 
 *  Compile: sudo gcc eZ430_getaccel.c -o eZ43_getaccel
 *  
 *  Description：使用樹莓派從 eZ430 運動手錶取得加速度與按鈕的資料
 * 
  *      The 'C' program does the following:
 *      Opens the serial port
 *      Sets it to 115,200 baud, no flow control
 *      Sends the hex string: 0xFF 0×07 0×03
 * 
 *      Check that the watch replies 0xFF 0×06 0×03 to confirm a connection has 
 *          been made
 *  Tip：
 *      程式流程大致如下：
 *      1.) 開啟串列埠
 *      2.) 設定串列埠，bud = 115,200，no flow control
 *      3.) 傳送 16 位元的字串：0xFF, 0x07, 0x03
 *      4.) 檢查手錶是否回傳 0xFF 0x06 0x03 -- yes --> 連線確定  -- no--> 回到步驟 1
 *      5.) 請手錶回傳資料，傳送需求碼 0xFF, 0×08, 0×07, 0×00, 0×00, 0×00, 0×00
 *      6.) 手機回傳資料(7-byte)，先確認前三個字元是 0xFF, 0x06, 0x07
 *          -- yes --> 步驟 7；-- no --> 步驟 5
 *      7.) 在螢幕顯示出所有的回傳字元 0xFF 0x06 0x07 tt xx yy zz --> 跳回步驟 5
 *          tt：哪一顆按鈕被按下 ( 左上, 左下還是右上)
 *          [ACC MODE]
 *              左上     = 0x11; 17
 *              左下     = 0x21; 33
 *              右上     = 0x31; 49
 *          xx：X 軸加速度值
 *          yy：Y 軸加速度值
 *          zz：Z 軸加速度值
 *  Result:  
 *      手錶面向上：
 *          往前轉 buffer[0] = 255 - 190；往後轉 buffer[0] = 0 - 60
 *          往右轉 buffer[1] = 255 - 190; 往左轉 buffer[1] = 0 - 60
 * 
*******************************************************************************/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <termios.h>
#include <sys/types.h>
#include <signal.h>
#include <sys/wait.h>

static unsigned char hello_str[3] = { 0xFF, 0x07, 0x03 };
static unsigned char req_data[7] = {0xFF, 0x08, 0x07, 0x00, 0x00, 0x00, 0x00};

typedef struct accdata {
    int x;
    int y;
    int z;
} ACCDATA;


static ACCDATA read_accel(int fd)
{
    char buffer[7];
    int i;
    ACCDATA acc;
    
    for(;;)
    {
        if(write(fd, req_data, sizeof(req_data)) != sizeof(req_data))
        {
            printf("Send request data to eZ430 error !\n");
            break;
        }
        
        if(read(fd, buffer, sizeof(buffer)) == -1)
        {
            printf("Reveice data from eZ430 error !\n");
            break;
        }
        
        if( buffer[0] == (char)0xff && buffer[1] == 0x06 && buffer[2] == 0x07 )
        {
            
            ///* 測試用，不用時將前面 // 取消掉
            for(i = 0;i < 7;i++)
            {
                printf("[%d]=%3d", i, buffer[i]);
            }
            printf("\r");
            //*/
            return acc;
        }
    }
}

/********************************************************************/
int main(int argc, char *argv[])
{
  int f;
  struct termios cf;
  ACCDATA ACC;

  if(argc != 2) {
    printf("usage: %s [serial port - usually /dev/ttyACM0]\n",argv[0]);
    return 0;
  }

  f = open(argv[1],O_RDWR);
  if(f == -1) {
    printf("Unable to open '%s'\n",argv[1]);
    return 0;
  }

  if(tcgetattr(f, &cf) == -1) {
    printf("Unable to get termios details\n");
    return 0;
  }

  if(cfsetispeed(&cf, B115200) == -1 || cfsetospeed(&cf, B115200) == -1) {
    printf("Unable to set speed\n");
    return 0;
  }

  /* Make it a raw stream and turn off software flow control */
  cfmakeraw(&cf);
  cf.c_iflag &= ~(IXON | IXOFF | IXANY);

  if(tcsetattr(f, TCSANOW, &cf) == -1) {
    printf("Unable to set termios details\n");
    return 0;
  }

  /* See if you can get a response to a hello */
  for(;;)
  {
    unsigned char hello_response[3];
    int i;

    usleep(250000);

    if(write(f,hello_str,sizeof(hello_str)) != sizeof(hello_str)) {
      printf("Unable to say hello\n");
      return 0;
    }

    i = read(f,hello_response,sizeof(hello_response));
    if(i < 0) {
      printf("Unable to read response\n");
      return 0;
    }

    if(i != sizeof(hello_response))
      continue;

    if(hello_response[0] == 0xFF && hello_response[1] == 0x6 && hello_response[2] == 0x3)
      break;
  }

  printf("Waiting for accelerometer\n");
  for(;;)
  {
    ACC = read_accel(f);
    //printf("ACC, x = %d, y = %d, z = %d\n");

    fflush(stdout);
    usleep(100000);
  }

  close(f);
  return 0;
}